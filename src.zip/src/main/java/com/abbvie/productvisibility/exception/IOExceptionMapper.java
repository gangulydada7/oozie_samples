package com.abbvie.productvisibility.exception;


/**
 * Class to map application related exceptions
 * 
 * @author Duraiarasan
 *
 */


import javax.servlet.http.HttpServlet;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

public class IOExceptionMapper extends HttpServlet {

	

}
