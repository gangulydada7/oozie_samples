package com.abbvie.productvisibility.to;

import java.io.Serializable;

public class SystemTO implements Serializable {


	private String systemID;

	private String systemName;

	public String getSystemID() {
		return systemID;
	}

	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	
	
	
}
